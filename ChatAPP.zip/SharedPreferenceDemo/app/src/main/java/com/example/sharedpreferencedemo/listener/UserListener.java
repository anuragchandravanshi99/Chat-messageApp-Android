package com.example.sharedpreferencedemo.listener;

import com.example.sharedpreferencedemo.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
