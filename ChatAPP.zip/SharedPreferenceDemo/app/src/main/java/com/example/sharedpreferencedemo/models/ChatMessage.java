package com.example.sharedpreferencedemo.models;

import java.util.Date;

public class ChatMessage {
    public String userId,receiverId,message,dateTime;
    public Date dateObject;
    public String conversationId,conversationName,conversationImage;
}
